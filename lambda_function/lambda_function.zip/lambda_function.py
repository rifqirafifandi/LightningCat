import json
import redis
import requests
import os

# Redis connection using ElastiCache endpoint
redis_client = redis.StrictRedis(
    host=os.environ['REDIS_HOST'], port=6379, decode_responses=True
)

def fetch_and_cache(api_url, cache_key, expiration=300):
    try:
        response = requests.get(api_url, timeout=10)
        response.raise_for_status()
        data = response.json()

        # Cache the latest data with expiration
        redis_client.set(cache_key, json.dumps(data), ex=expiration)
        return {"status": "success", "data": data}

    except Exception as e:
        return {"status": "error", "message": str(e)}

def lambda_handler(event, context):
    api_url = event.get("api_url")
    cache_key = event.get("cache_key")

    if not api_url or not cache_key:
        return {"statusCode": 400, "body": json.dumps({"error": "Missing parameters"})}

    result = fetch_and_cache(api_url, cache_key)
    return {"statusCode": 200, "body": json.dumps(result)}